package com.example.test_v2;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.test_v2.fileAndDatabase.HelperAppDatabase;
import com.example.test_v2.timer.HelperTimerEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class TimerPage extends AppCompatActivity {

    // UI elements
    private Button backButton;
    private TextView timerDisplay;
    private Button toggleTimerButton;  // Single big button: Start → Pause → Resume
    private Button addTimeButton, viewPastTimesButton;
    private ScrollView actionLogScroll;
    private LinearLayout actionLogContainer;

    // Timer state
    private boolean isRunning = false;
    private boolean hasEverRun = false;

    //real-time storing
    private long baseTimeMs = 0L; // Real time at last start/resume
    private long totalActiveBeforeResume = 0L;

    // For logging intervals: [startRealMs, endRealMs], using currentTimeMillis
    private List<long[]> intervals = new ArrayList<>();

    // measure run intervals
    private long lastResumeMs = 0L;
    private long lastPauseMs = 0L;

    // store user actions (start/pause/resume) messages
    private ArrayList<String> actionLogMessages = new ArrayList<>();

    // update the display ~30 times/second
    private Handler timerHandler = new Handler();
    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                long now = System.currentTimeMillis();
                long elapsedActiveMs = totalActiveBeforeResume + (now - baseTimeMs);
                timerDisplay.setText(formatElapsed(elapsedActiveMs));
                timerHandler.postDelayed(this, 33L);
            }
        }
    };

    // Database
    private HelperAppDatabase db;
    private String currentUserId = "-1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer_page);

        db = HelperAppDatabase.getDatabase(getApplicationContext());

        // get the current user from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        currentUserId = prefs.getString("loggedInPin", "-1");

        // Find UI
        backButton = findViewById(R.id.back_button_bottom);
        timerDisplay = findViewById(R.id.timer_display);
        toggleTimerButton = findViewById(R.id.toggle_timer_button);
        addTimeButton = findViewById(R.id.add_time_button);
        viewPastTimesButton = findViewById(R.id.view_past_times_button);
        actionLogScroll = findViewById(R.id.action_log_scroll);
        actionLogContainer = findViewById(R.id.action_log_container);

        timerDisplay.setText("00:00:00.000");
        toggleTimerButton.setText("Start");

        backButton.setOnClickListener(v -> finish());
        toggleTimerButton.setOnClickListener(v -> handleToggleButton());
        addTimeButton.setOnClickListener(v -> finalizeAndSave());
        viewPastTimesButton.setOnClickListener(v ->
                startActivity(new android.content.Intent(this, TimerHistoryPage.class))
        );
    }

    private void handleToggleButton() {
        if (!hasEverRun) {
            // START
            startTimer();
            hasEverRun = true;
            toggleTimerButton.setText("Pause");
            appendActionLog("User started timer at " + getCurrentTimeString());

        } else if (isRunning) {
            // PAUSE
            pauseTimer();
            long runInterval = System.currentTimeMillis() - lastResumeMs;
            appendActionLog("User paused at " + getCurrentTimeString()
                    + " after " + formatElapsed(runInterval) + " run");
            toggleTimerButton.setText("Resume");

        } else {
            // RESUME
            resumeTimer();
            long pausedInterval = System.currentTimeMillis() - lastPauseMs;
            appendActionLog("User resumed at " + getCurrentTimeString()
                    + " after " + formatElapsed(pausedInterval) + " paused");
            toggleTimerButton.setText("Pause");
        }
    }

    private void startTimer() {
        if (!isRunning && intervals.isEmpty()) {
            isRunning = true;
            hasEverRun = true;

            long now = System.currentTimeMillis();
            baseTimeMs = now;
            totalActiveBeforeResume = 0L;

            lastResumeMs = now;
            lastPauseMs = 0L;

            // store real start in intervals
            intervals.add(new long[]{ now, -1 });

            timerHandler.post(timerRunnable);
        }
    }

    private void pauseTimer() {
        if (isRunning) {
            isRunning = false;
            long now = System.currentTimeMillis();
            // close out last active interval
            if (!intervals.isEmpty()) {
                intervals.get(intervals.size() - 1)[1] = now;
            }
            totalActiveBeforeResume += (now - baseTimeMs);
            lastPauseMs = now;
            timerHandler.removeCallbacks(timerRunnable);
        }
    }

    private void resumeTimer() {
        if (!isRunning && hasEverRun) {
            isRunning = true;
            long now = System.currentTimeMillis();
            baseTimeMs = now;
            lastResumeMs = now;

            intervals.add(new long[]{ now, -1 });
            timerHandler.post(timerRunnable);
        }
    }

    private void finalizeAndSave() {
        if (isRunning) {
            pauseTimer();
        }
        removeEmptyInterval();

        long totalActiveMs = totalActiveBeforeResume;
        if (totalActiveMs <= 0) {
            Toast.makeText(this, "No time recorded", Toast.LENGTH_SHORT).show();
            resetTimer();
            return;
        }

        appendActionLog("Event ended at " + getCurrentTimeString()
                + ", total " + formatElapsed(totalActiveMs));

        // Combine action logs
        StringBuilder sb = new StringBuilder();
        for (String line : actionLogMessages) {
            sb.append(line).append("\n");
        }
        String finalActionLog = sb.toString().trim();

        String intervalsJson = buildIntervalsJson(intervals);

        // Insert into DB
        new Thread(() -> {
            HelperTimerEvent event = new HelperTimerEvent();
            event.userId = currentUserId;
            event.startTimestamp = intervals.get(0)[0];
            event.totalTimeMs = totalActiveMs;
            event.intervalsJson = intervalsJson;
            event.notes = "";
            event.actionLog = finalActionLog;
            event.eventName = "Timer Event"; // default name if not renamed

            db.timerEventDao().insert(event);
        }).start();

        Toast.makeText(this, "Timer saved (" + formatElapsed(totalActiveMs) + ")", Toast.LENGTH_SHORT).show();
        resetTimer();
    }

    private void removeEmptyInterval() {
        if (!intervals.isEmpty()) {
            long[] last = intervals.get(intervals.size() - 1);
            if (last[1] < 0) {
                intervals.remove(intervals.size() - 1);
            }
        }
    }

    private String buildIntervalsJson(List<long[]> intervals) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < intervals.size(); i++) {
            long[] iv = intervals.get(i);
            sb.append("{\"start\":").append(iv[0])
                    .append(",\"end\":").append(iv[1]).append("}");
            if (i < intervals.size() - 1) sb.append(",");
        }
        sb.append("]");
        return sb.toString();
    }

    private String formatElapsed(long ms) {
        int totalMs = (int) ms;
        int sec = totalMs / 1000;
        int milli = totalMs % 1000;
        int min = sec / 60;
        int hrs = min / 60;
        sec = sec % 60;
        min = min % 60;
        return String.format("%02d:%02d:%02d.%03d", hrs, min, sec, milli);
    }

    private void resetTimer() {
        timerHandler.removeCallbacks(timerRunnable);

        isRunning = false;
        hasEverRun = false;
        baseTimeMs = 0L;
        totalActiveBeforeResume = 0L;
        lastResumeMs = 0L;
        lastPauseMs = 0L;

        intervals.clear();
        actionLogMessages.clear();

        timerDisplay.setText("00:00:00.000");
        toggleTimerButton.setText("Start");
        actionLogContainer.removeAllViews();
        clearSavedTimerState();
    }

    private void appendActionLog(String msg) {
        actionLogMessages.add(msg);
        TextView tv = new TextView(this);
        tv.setText(msg);
        tv.setTextSize(14f);
        actionLogContainer.addView(tv);

        actionLogScroll.post(() -> actionLogScroll.fullScroll(View.FOCUS_DOWN));
    }

    private String getCurrentTimeString() {
        // This is just for display, no effect on intervals
        SimpleDateFormat sdf = new SimpleDateFormat("h:mm:ss a");
        return sdf.format(new Date());
    }

    @Override
    protected void onResume() {
        super.onResume();
        restoreTimerState();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveTimerState();
    }

    private void saveTimerState() {

    }

    private void restoreTimerState() {

    }

    private void clearSavedTimerState() {

    }
}
